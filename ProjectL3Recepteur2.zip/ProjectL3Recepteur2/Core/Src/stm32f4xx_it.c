/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f4xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h> 		// Utilisation de la fonction printf
#include <string.h> 	// Manipulation de chaînes de caractère
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define THRESHOLD 1200	// Seuil à partir duquel un son est détecté - valeur numérique donnée par l'ADC depuis le micro
						// Sachant que la valeur max sur notre ADC correspond à 3.3V et que le micro peut donner une impulsion max de 2V soit 60db
						// 2v*4096/3.3V=2480 avec une marge d'erreur de -40 V
						// Ce seuil correspond environ à 30db
#define BUFF_MAX 100 	// Nombre max de caractères pouvant être envoyés par l'émetteur
#define UNIT 160		// Une unité de temps pour notre code morse
#define SAMPLING 80 	// Période d'échantillonage

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
const int sampPerUnit=UNIT/SAMPLING;		// Le nombre d'echantillons de l'ADC devant avoir été reçus pour une unité de temps
											// Ici 2
int state=1; 	// Booléen permettant de traquer si le micro est en train de capter un son ou non
				// 1 = son en cours, 0 sinon
				// 1 par défaut car on ne démarre les échantillons que lorsqu'un son est capté

int readMsg=0; 	// Indique si un message est en cours de lecture

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */
void decodeMorse(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern TIM_HandleTypeDef htim3;
/* USER CODE BEGIN EV */
extern ADC_HandleTypeDef hadc1;

extern char coded[BUFF_MAX*6 + 2]; // Chaîne pour stocker la version codée reçue par signaux sonores
			// Taille max d'un caractère en morse est 5 - ils sont associés soit à un - pour la lettre suivante, soit d'un + pour un espace entre mots
			// On y place les caractères morses interprétes grâce au tim3
/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
   while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Pre-fetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F4xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f4xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles TIM3 global interrupt.
  * Période de 80ms - 2 échantilons par unité de temps -
  */
void TIM3_IRQHandler(void)
{
  /* USER CODE BEGIN TIM3_IRQn 0 */
	static int nbrSample = 1;  // Le nombre d'échantilons de valeurs pris avec l'état du micro actuel

	HAL_ADC_Start(&hadc1);								// On démarre l'ADC
	HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);	// On attend que la conversion soit finalisée (en mode Continu)

	// Start decrypting only when above the threshold

	uint32_t val = HAL_ADC_GetValue(&hadc1); // Récupère la vaeur la plus récente convertie par l'ADC

	if (val > THRESHOLD) {		// Si le seuil de détection de bruit est dépassé une première fois, on active le booléen
		readMsg=1;
	}

	if (readMsg) {		// Si un message est en cours d'envoi
		float nbrUnit= (float)nbrSample/(float)sampPerUnit;	// On calcule le nombre d'unités déjà reçu pour l'état du micro actuel
		if (nbrUnit > 5) { 									// Le message est fini (la plus longue durée dans le code est de 5 unités)
			readMsg=0;										// Réinitialise le booléen = plus de message en cours
			state=1;										// L'état est remis à 1 pour la prochaine détection
			nbrSample=1;									// Idem
			decodeMorse();									// On appele la fonction qui récupère la chaîne codée et la décrypte

			// Les deux prochaines lignes sont si l'on souhaite stopper la conversion en dehors des moments demandés
			// Elles peuvent être retirés mais il ne faudra pas capter de son entre temps
			HAL_TIM_Base_Stop_IT(&htim3);					// On arrête le timer 3, il faut rappuyer sur le bouton pour  le relancer
			HAL_ADC_Stop(&hadc1);							// On arrête l'ADC, rappuyer sur le bouton
			return;											// Pour ne pas exécuter le reste
		}

		int newState=0;				// On détermine l'état du micro actuel, pendant ce tour
		if (val > THRESHOLD) {
			newState=1;
		}

		if (newState != state) {	// S'il diffère de ceui précedemment enregistré
			char car='$';
			switch( (int) nbrUnit) {		// On détermine le symbole en fonction du nombre d'unités lues
				case 1:
					if (state) {
						car='.';	// Si le micro captait un son, c'est un point
					}
					break;
				case 3:
					if (state) {
						car='-'; 	// Si le micro captait un son, c'est un trait
					}
					else {
						car='_';	// Sinon, c'est un espace entre deux lettres
					}
					break;
				case 5:
					car='+';		// 5 unités est forcément un espace entre mots
			}
			if (car != '$') {		// Si aucun de ceux pus haut, c'est un blanc entre deux symboles morses que l'on n'écrit pas dans la chaîne
				char temp2[2]={car, '\0'};
				strncat(coded, temp2, 1);  // Ajoute seulement le caractère décodé au message crypté
			}
			nbrSample=1;				// On remet le nombre d'échantillons à 1 pour les prochains signaux
			state=newState;				// On change l'état actuel du micro
		}
		else {
			nbrSample++;				// On incrémente le nombre d'échantilons
		}
	}


  /* USER CODE END TIM3_IRQn 0 */
  HAL_TIM_IRQHandler(&htim3);
  /* USER CODE BEGIN TIM3_IRQn 1 */

  /* USER CODE END TIM3_IRQn 1 */
}

/**
  * @brief This function handles EXTI line[15:10] interrupts.
  */
void EXTI15_10_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI15_10_IRQn 0 */
	HAL_TIM_Base_Start_IT(&htim3);	// On démarre le timer à l'appui du bouton - Pour éviter d'avoir le micro qui tourne en continu dès que la carte est connectée
									// De cette manière, on choisit quand commencer l'échantillonage
  /* USER CODE END EXTI15_10_IRQn 0 */
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_13);
  /* USER CODE BEGIN EXTI15_10_IRQn 1 */

  /* USER CODE END EXTI15_10_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
