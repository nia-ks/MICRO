/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h> 		// Utilisation de la fonction printf
#include <string.h> 	// Manipulation de chaînes de caractère
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define UNIT 160 // Une unité de temps est établie à 160ms - Pour déterminer la durée des signaux du buzzer
#define BUFF_MAX 100 // Taille du buffer en réception - nombre de caractères max pouvant être lus

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
DAC_HandleTypeDef hdac;

TIM_HandleTypeDef htim5;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

uint8_t rx_buffer[BUFF_MAX + 1]; // Buffer pour le stockage des lettres reçues via l'UART

int ind=0; // ind qui indique combien de lettres pour le message actuel ont déjà été reçues
			// = Où écrire dans le buffer + Réinitialisé à la fin du message

char coded[BUFF_MAX*6 + 2]=""; // Chaîne pour stocker la version décodée
			// Taille max d'un caractère en morse est 5 - ils sont associés soit à un _ pour la lettre suivante, soit d'un + pour un espace entre mots
/* Règles du codage
. (point) = 1 unité
- (trait) = 3 unités
_ (espace entre deux lettres du même mot) = 3 unités
+ (espace entre deux mots) = 5 unités
*/
char *morseLetters[26] = { // Tableau contenant les codes Morse des lettres dans l'ordre ASCII
    ".-",      // A
    "-...",    // B
    "-.-.",    // C
    "-..",     // D
    ".",       // E
    "..-.",    // F
    "--.",     // G
    "....",    // H
    "..",      // I
    ".---",    // J
    "-.-",     // K
    ".-..",    // L
    "--",      // M
    "-.",      // N
    "---",     // O
    ".--.",    // P
    "--.-",    // Q
    ".-.",     // R
    "...",     // S
    "-",       // T
    "..-",     // U
    "...-",    // V
    ".--",     // W
    "-..-",    // X
    "-.--",    // Y
    "--.."     // Z
};

char *morseNum[10] = { // Tableau contenant les codes Morse des chiffres
    "-----",   // 0
    ".----",   // 1
    "..---",   // 2
    "...--",   // 3
    "....-",   // 4
    ".....",   // 5
    "-....",   // 6
    "--...",   // 7
    "---..",   // 8
    "----."    // 9
};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM5_Init(void);
static void MX_DAC_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

// Le code qui suit permet d'utiliser la fonction printf avec une sortie via l'UART
#ifdef __GNUC__
/* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small
printf
 set to 'Yes') calls __io_putchar() */
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */

PUTCHAR_PROTOTYPE
{
	/* Place your implementation of fputc here */
	/* e.g. write a character to the USART2 and Loop until the end of
	transmission */
	HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, 0xFFFF);

	// En redéfinissant la fonction putchar sur laquelle est basée printf, sa sortie se fera maintenant sur l'UARt (Transmit)

	return ch;
}

int isCap(uint8_t car) { // Indique si un caractère donné par son code ASCII est une lettre majuscule
	return  ( (car>='A') && (car<='Z') );
}

int isLowercase(uint8_t car) { // Indique si un caractère donné par son code ASCII est une lettre minuscule
	return ( (car>='a') && (car<='z') );
}

int isANumber(uint8_t car) {  // Indique si un caractère donné par son code ASCII est un chiffre
	return ( (car>='0') && (car<='9') );
}

char *charToMorse(uint8_t car) { // Rend l'équivalent morse d'un caractère
	if (isCap(car)) {
		return morseLetters[car-'A'];
		// Si majuscule, décale de 'A' (pour A, on renverra morse[0], pour B 1, ...)
	}

	if (isLowercase(car)) {
		return morseLetters[car-'a'];
		// Si minuscule, décale de 'a' (pour a, on renverra morse[0], pour b 1, ...)
	}

	if (isANumber(car)) {
		return morseNum[car-'0'];
		// Si chiffre, décale de '0' (pour 0, on renverra morse[0], pour 1 1, ...)
	}

	/*
	if ((car == '\'') || (car == ' ')) {
		return "+"; // Rend l'équivalent d'un espace pour l'apostrophe
	}

	if (((int)car == 'é') || ((int)car == 'è')) {
		return morseLetters['e'-'a'];
	}

	if ((int)car == 'à') {
		return morseLetters['a'-'a'];
	}

	if ((int)car == 'ù') {
		return morseLetters['u'-'a'];
	}

	 // Gestion des accents */

	return "";  // Ne rend rien par défaut pour les autres caractères

}

uint32_t duree(char car) { // Associe à un caractère de la chaîne morse sa durée sur le buzzer en unités de temps = Le nombre de tours de timers
	if (car == '.') {
		return 1; // Un point est une seule unité
	}

	if ((car == '-') || (car == '_')) {
		return 3; // Un trait ou un espace entre les lettres correspond à 3 unités
	}

	if (car == '+') {
		return 5; // Un espace entre les mots est 5 unités - réduit par rapport au code officiel pour gain de temps
	}
	return 0; // Retourne 0 pour les autres caractères
}

void read_text() {
		printf("Votre message est le suivant : %s\r\n", rx_buffer);
		// Grâce à notre réecriture de la fonction fputchar, notre printf est envoyé via l'UART
		// On restitue le message tel que tapé par l'utiisateur

		int length = strlen((char *) rx_buffer);
		// On récupère le nombre de caractères tapés (cela inclut le \r de fin)

		sprintf(coded, "_");						// On commence la chaîne codée par un temps de pause
		for (int i=0; i<length; i++) {				// On parcourt le buffer
			uint8_t car = rx_buffer[i];				// Le caractère à lire
			char *morseCar = charToMorse(car);		// Chaîne temporaire pour stocker le code morse du caractère en cours
			char strCar[7]="";						// Chaîne temporaire pour stocker le texte à ajouter à la chaîne décodée
			if (car == ' ') {						// Un espace dans le texte correspond à un + dans notre code morse

				if (i>0) {
					sprintf(strCar, "+");			// Si l'espace est au début, on ne le lit pas (cause un décalage avec le timer sinon)
				}
				else {

				}
				while (rx_buffer[i+1] == ' ') {		// Si pusieurs espaces d'affilée, on ne traite qu'un seul fois
					i++;
				}
			}
			else {
				if ( (strcmp(morseCar, "") == 0) || (strcmp(charToMorse(rx_buffer[i+1]), "+") == 0)) {
					sprintf(strCar, "%s", morseCar);
					// Si on a un caractère non valide en morse, ou que le prochain caractère est un espace, on ne marque pas 3 unités d'arrêt après
				}
				else {
					sprintf(strCar, "%s_", morseCar);
					// Le prochain caractère est une lettre valide, on ajoute un _ pour marquer 3 unités d'arrêt après
				}
			}
			strcat(coded,strCar);			// On concatène notre code morse à la chaîne globale de codage
			memset(morseCar, 0, 5);			// On vide le tableau nous servant à traduire pour les prochaines lettres
		}

		printf("Sa traduction en morse est la suivante :");

		for (int j=0; coded[j] != '\0'; j++) {
		// Boucle for afin de pouvoir remplacer certains caractères pour l'affichage
			if (coded[j]=='+') {
				printf("   "); 				// Grand espace entre les mots
			}
			else if (coded[j]=='_') {
				printf(" ");				// Simple espace entre les lettres
			}
			else {
				printf("%c", coded[j]); 	// Affichage du symbole
			}
		}
		printf("\r\n\n");
		ind=0;								// L'indice indiquant où écrire les lettres reçues depuis l'UART dans buffer est réinitialisé
											// On peut recevoir un nouveau message sans


		HAL_TIM_Base_Start_IT(&htim5); 		// Le timer d'une période de 160ms démarre, il gère toutes les émissions du buzzer
											// Plus de détails sur ce procédé dans sa fonction d'interruption

		/*			POUR LE DEBUG
		int lengthDeco = strlen(coded);
		for (int i=0; i<lengthDeco; i++) {
			char carDeco = coded[i];
			if ( (carDeco == '.') || (carDeco == '_') ) {
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5,GPIO_PIN_SET);
				delay(duree(carDeco));
				if ( (coded[i+1] == '.') || (coded[i+1] == '_') ) {
					HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5,GPIO_PIN_RESET);
					delay(UNIT);
				}
			}
			else {
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5,GPIO_PIN_RESET);
				delay(duree(carDeco));
			}
		}
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5,GPIO_PIN_RESET);
		 */
	}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM5_Init();
  MX_DAC_Init();
  /* USER CODE BEGIN 2 */
  HAL_UART_Receive_IT(&huart2, rx_buffer+ind, 1); // On démarre la réception avec interruption de l'UART
  	  	  	  	  	  	  	  	  	  	  	  	  // En lui indiquant d'écrire dans le buffer (ind vaut 0 à ce stade)

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief DAC Initialization Function
  * @param None
  * @retval None
  */
static void MX_DAC_Init(void)
{

  /* USER CODE BEGIN DAC_Init 0 */

  /* USER CODE END DAC_Init 0 */

  DAC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN DAC_Init 1 */

  /* USER CODE END DAC_Init 1 */

  /** DAC Initialization
  */
  hdac.Instance = DAC;
  if (HAL_DAC_Init(&hdac) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT1 config
  */
  sConfig.DAC_Trigger = DAC_TRIGGER_NONE;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DAC_Init 2 */

  /* USER CODE END DAC_Init 2 */

}

/**
  * @brief TIM5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.Prescaler = 251;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5.Init.Period = 53332;
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
 // On se sert de PA8 pour la sortie buzzer, ce GPIO est donc en mode Output
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PA8 */
  GPIO_InitStruct.Pin = GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
// Callback de la fonction de réception avec IT de l'UART2
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
	// Quand on reçoit le caractère \r dans le buffer ou qu'on en a dépassé la taille, on arrête la lecture des caractères et on les code
	if ( (rx_buffer[ind] == 13) || (ind>=BUFF_MAX) ) { // End transmission
		read_text();		// Fonction chargée d'encoder le texte et l'emettre sur le buzzer + réinitialise les chaînes et l'indice
	}
	else {
		ind++;				// Sinon, on continue de lire les caractères reçus un par un en incrémentant l'indice du buffer
	}
	HAL_UART_Receive_IT(&huart2, rx_buffer+ind, 1); // On relance la réception avec le nouvel indice
	//HAL_UART_Transmit(&huart2, rx_buffer, 100, 0xFFFF);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
