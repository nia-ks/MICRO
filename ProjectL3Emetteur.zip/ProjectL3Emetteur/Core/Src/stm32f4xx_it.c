/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f4xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h> 		// Utilisation de la fonction printf
#include <string.h> 	// Manipulation de chaînes de caractère
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define BUFF_MAX 100 // Taille du buffer en réception - nombre de caractères max pouvant être lus via l'UART
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
int step=1;		// Sert à trackerle nombre de tours du timer pour les caractères sur plusieurs unités
static int idx = 0; 			// Index de la lettre à lire dans le buffer
static int pause=0; 			// Booléen utilisé pour détecter un espace entre deux symboles morses

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */
extern uint32_t duree(char car);		// On importe la fonction duree pour connaître le nombre de tours d'un caractère
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern DAC_HandleTypeDef hdac;
extern TIM_HandleTypeDef htim5;
extern UART_HandleTypeDef huart2;
/* USER CODE BEGIN EV */
extern int ind;
extern uint8_t rx_buffer[BUFF_MAX + 1]; 	// Importation du buffer pour le stockage des lettres reçues via l'UART - pour le vider après lecture
extern char coded[BUFF_MAX*6 + 2];			// Importation de la chaîne codée de morse pour pouvoir lire et envoyer le bon message au buzzer
/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
   while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Pre-fetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F4xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f4xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles USART2 global interrupt.
  */
void USART2_IRQHandler(void)
{
  /* USER CODE BEGIN USART2_IRQn 0 */

	// Callback dans main après USER CODE BEGIN 4

  /* USER CODE END USART2_IRQn 0 */
  HAL_UART_IRQHandler(&huart2);
  /* USER CODE BEGIN USART2_IRQn 1 */

  /* USER CODE END USART2_IRQn 1 */
}

/**
  * @brief This function handles EXTI line[15:10] interrupts.
  * Quand on appuie sur le bouton, a transmission actuelle est arrêtée - le buffer est vidé
  */
void EXTI15_10_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI15_10_IRQn 0 */
	HAL_TIM_Base_Stop_IT(&htim5); 							// On arrete le timer - plus d'interruptions
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8,GPIO_PIN_RESET);	// On éteint la Pin pour s'assurer que le buzzer s'arrête
	printf("Annule\r\n\n");
	memset((char *) rx_buffer, 0, sizeof(rx_buffer));
	memset((char *) coded, 0, sizeof(coded));			// On vide les deux tableaux nous servant à traduire pour les prochains messages
	idx=0;				// L'index de lecture du morse pour le timer revient à 0 - nécessaire car il est static
	pause=0;			// Pause revient à 0 (par sécurité, mais il devrait déjà l'être)
	HAL_UART_Receive_IT(&huart2, rx_buffer, 1); // On démarre la réception avec interruption de l'UART
	  	  	  	  	  	  	  	  	  	  	  	  	  // En lui indiquant d'écrire dans le buffer (ind vaut 0 à ce stade)
	ind=0;

	//HAL_Delay(100);

  /* USER CODE END EXTI15_10_IRQn 0 */
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_13);
  /* USER CODE BEGIN EXTI15_10_IRQn 1 */

  /* USER CODE END EXTI15_10_IRQn 1 */
}

/**
  * @brief This function handles TIM5 global interrupt.
  */
void TIM5_IRQHandler(void)
{
  /* USER CODE BEGIN TIM5_IRQn 0 */
	// Cette fonction est appelée à chaque interruption du Timer, qui a une fréquence de 6.25 HZ
	// Soit 6.25 interruptions par seconde
	// Période 160 ms

	char car = coded[idx];			// Le caractère en cours de lecture
	uint32_t delay = duree(car);	// Le nombre de tours de timer associés à ce caractère

	if (idx < strlen(coded)) {		// Tant que l'on a pas lu tous les caractères morses
		if (pause) { 				// Un tour où l'on ne lit pas de caractère puis on relance le son du buzzer
			pause=0;				// Pause revient à 0 car l'espace a été lu
			HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_8);		// Après cette pause, on relance le buzzer pour le prochain caractère
		}
		else if (step < delay) {
			step++;								// Le nombre de tours pour ce caractère n'est pas encore atteint - on incrémente
		}
		else {
			if (coded[idx+1] != '\0') {		// Si l'on a atteint le dernier caractère morse, on ne rallume pas le buzzer
				HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_8);
				// On inverse l'état du buzzer - le morse est une alternance de sons et de silences
				// Il nous suffit simplement d'utiliser notre timer et de compter des tours pour choisir la durée de ces phases
			}
			if ( (car == '.') || (car == '-') ) {
				if ( (coded[idx+1] == '.') || (coded[idx+1] == '-') ) {
					pause=1; 	// On détecte deux caractères morses qui se suivent pour marquer une pause d'une unité
				}
			}
			step=1; 			// On réinitalise le nombre d'unités pour le prochain caractère
			idx++;				// On lit le prochain caractère en incrémentant l'indice
		}
	}
	else {
		// La fin du code morse a été atteinte
		HAL_TIM_Base_Stop_IT(&htim5); 							// On arrete le timer - plus d'interruptions
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8,GPIO_PIN_RESET);	// On éteint la Pin pour s'assurer que le buzzer s'arrête
		memset((char *) rx_buffer, 0, sizeof(rx_buffer));
		memset((char *) coded, 0, sizeof(coded));			// On vide les deux tableaux nous servant à traduire pour les prochains messages
		idx=0;				// L'index de lecture du morse pour le timer revient à 0 - nécessaire car il est static
		pause=0;			// Pause revient à 0 (par sécurité, mais il devrait déjà l'être)
	}
  /* USER CODE END TIM5_IRQn 0 */
  HAL_TIM_IRQHandler(&htim5);
  /* USER CODE BEGIN TIM5_IRQn 1 */

  /* USER CODE END TIM5_IRQn 1 */
}


/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
